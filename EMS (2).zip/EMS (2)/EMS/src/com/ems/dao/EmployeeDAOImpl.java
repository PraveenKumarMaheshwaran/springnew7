package com.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;


@Repository
@Transactional
public class EmployeeDAOImpl implements IEmployeeDAO {
    
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		
		int id=0;
		
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getEmployeeId();
		} catch (Exception e) {
			
			throw new EmployeeException("Unable to persist in dao layer"+e.getMessage());
		}
		
		return id;
	}
	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		
	 List<EmployeeBean> list=null;
	try {
		TypedQuery<EmployeeBean> query=entityManager.createQuery("select e from EmployeeBean e",EmployeeBean.class);
		 list = query.getResultList();
	} catch (Exception e) {
		
		throw new EmployeeException("Unable to fetch record in dao layer"+e.getMessage());
		
	}
		
	 return list;
	}
	@Override
	public boolean deleteEmployee(int Id) throws EmployeeException {
		boolean isDeleted=false;
		try {
			EmployeeBean bean=entityManager.find(EmployeeBean.class, Id);
			entityManager.remove(bean);
			isDeleted=true;
		} catch (Exception e) {
			throw new EmployeeException("unable to delete the records"+e.getMessage());
		}
		
		return isDeleted;
		
	}

}
